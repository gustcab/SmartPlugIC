package smartplug.smartplug.Adapter;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import smartplug.smartplug.R;
import smartplug.smartplug.entidades.Produtos;

public class ProdutosAdapter extends ArrayAdapter<Produtos> {

    private ArrayList<Produtos> produto;
    private Context context;

    public ProdutosAdapter(Context c, ArrayList<Produtos> objects){
        super(c, 0, objects);
        this.context = c;
        this.produto = objects;
    }


    @Override
    public View getView(int position,  View convertView,  ViewGroup parent) {

        View view = null;

        if(produto !=null)
        {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);

            view = inflater.inflate(R.layout.lista_conectados, parent, false);

            TextView txtNome = (TextView) view.findViewById(R.id.txtNome);
            TextView txtIp = (TextView) view.findViewById(R.id.txtIp);

            Produtos produto2 = produto.get(position);

            txtNome.setText(produto2.getNome());
            txtIp.setText(produto2.getValor().toString());

        }
        return view;
    }



}
