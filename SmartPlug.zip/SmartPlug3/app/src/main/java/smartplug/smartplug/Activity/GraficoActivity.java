package smartplug.smartplug.Activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.LinearLayout;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.Viewport;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.Random;

import smartplug.smartplug.R;

public class GraficoActivity extends AppCompatActivity {

    private LinearLayout ll;
    private static final Random RANDOM = new Random();
    private LineGraphSeries<DataPoint> series;
    private int lastX = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grafico);

        /*
        int i, tam = 200;
        double v = 0;

        // SENO
        GraphView.GraphViewData[] data = new GraphView.GraphViewData[tam];
        for(i = 0; i < tam; i++){
            v +=0.3;
            data[i] = new GraphView.GraphViewData(i, Math.sin(v));
        }

        // Label de Seno
        GraphViewSeries seriesSeno = new GraphViewSeries("Seno", new GraphViewSeries.GraphViewSeriesStyle(Color.BLUE,3), data);


        // COSSENO
        data = new GraphView.GraphViewData[tam];
        for(i = 0; i < tam; i++){
            v +=0.3;
            data[i] = new GraphView.GraphViewData(i, Math.cos(v));
        }

        // Label do Cosseno
        GraphViewSeries seriesCosseno = new GraphViewSeries("Cosseno", new GraphViewSeries.GraphViewSeriesStyle(Color.GREEN,3), data);


        LineGraphView graph = new LineGraphView(this, "Dados");
        graph.addSeries(seriesSeno);    // Adiciona a serie do Seno
        graph.addSeries(seriesCosseno); // Adiciona a serie do Cosseno

        graph.setShowLegend(true);
        graph.setLegendAlign(GraphView.LegendAlign.BOTTOM);

        graph.getGraphViewStyle().setGridColor(Color.GRAY);
        graph.getGraphViewStyle().setHorizontalLabelsColor(Color.BLACK);
        graph.getGraphViewStyle().setVerticalLabelsColor(Color.BLACK);
        graph.getGraphViewStyle().setTextSize(15);

        /*graph.setVerticalLabels(new String[]{"y1", "y2", "y3", "y4"});
        graph.setHorizontalLabels(new String[]{"x1", "x2", "x3", "x4"});*/

      /*  graph.setCustomLabelFormatter(new CustomLabelFormatter() {
            @Override
            public String formatLabel(double v, boolean isValueX) {

                if(isValueX){
                    if(v > 2){
                        return ("x1");
                    }
                    else {
                        return ("x2");
                    }
                }
                else{
                    if(v > 2){
                        return ("y1");
                    }
                    else {
                        return ("y2");
                    }
                }

            }
        });

        graph.setViewPort(10, 30); // Limite de visualização
        graph.setScrollable(true); // Ativa o rolamento da tela
        graph.setScalable(true); // Ativa o dimensionamento

      /*  graph.setDrawBackground(true); // Pinta o fundo do grafico
        graph.setBackgroundColor(Color.BLUE);

        ll = (LinearLayout) findViewById(R.id.grafico_inteiro);
        ll.addView(graph);
        */

        GraphView graph = (GraphView) findViewById(R.id.grafico_inteiro);
        //data
        series = new LineGraphSeries<DataPoint>();
        graph.addSeries(series);
        //customize
        Viewport viewport = graph.getViewport();
        viewport.setYAxisBoundsManual(true);
        viewport.setMinY(0);
        viewport.setMaxY(10);
        viewport.setScrollable(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //we´re going to simulate real time with thread that append data to the graph
        new Thread(new Runnable() {
            @Override
            public void run() {
                // we add 100 new entries
                for(int i = 0; i < 100; i++){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            addEntry();
                        }
                    });

                    // sleep to slow down the add of entries
                    try {
                        Thread.sleep(600);
                    } catch (InterruptedException e) {
                        // manage error ...

                    }
                }
            }
        }).start();
    }

    // add random data to graph
    private void addEntry(){

        // here we choose to display max 10 points on the viewport and we scroll to end
        series.appendData(new DataPoint(lastX++, RANDOM.nextDouble() * 10d), true, 10);

    }
}
