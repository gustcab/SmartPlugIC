package smartplug.smartplug.Activity;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import smartplug.smartplug.Adapter.ProdutosAdapter;
import smartplug.smartplug.DAO.ConfiguracaoFirebase;
import smartplug.smartplug.R;
import smartplug.smartplug.entidades.Produtos;

public class ProdutosActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter<Produtos> adapter;
    private ArrayList<Produtos> produtos;
    private DatabaseReference firebase;
    private ValueEventListener valueEventListenerProdutos;
    private Button btnVoltarTelaInicial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produtos);

        produtos = new ArrayList<>();

        listView = (ListView) findViewById(R.id.listViewConectados);
        adapter = new ProdutosAdapter(this, produtos);

        listView.setAdapter(adapter);

        firebase = ConfiguracaoFirebase.getFirebase().child("addaparelho");

       valueEventListenerProdutos = new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               produtos.clear();

               for(DataSnapshot dados: dataSnapshot.getChildren()){
                   Produtos produtosNovos = dados.getValue(Produtos.class);

                   produtos.add(produtosNovos);
               }

               adapter.notifyDataSetChanged();
           }

           @Override
           public void onCancelled(@NonNull DatabaseError databaseError) {

           }
       };

       btnVoltarTelaInicial = (Button) findViewById(R.id.btnVoltarTelaInicial2);
       btnVoltarTelaInicial.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               voltarTelaInicial();

           }
       });
    }
    private void voltarTelaInicial(){
        Intent intent = new Intent(ProdutosActivity.this, HomeActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onStop() {
        super.onStop();
        firebase.removeEventListener(valueEventListenerProdutos);
    }

    @Override
    protected void onStart() {
        super.onStart();
        firebase.addValueEventListener(valueEventListenerProdutos);
    }
}
