package smartplug.smartplug.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;

import com.google.firebase.auth.FirebaseAuth;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.Viewport;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.Random;

import smartplug.smartplug.DAO.ConfiguracaoFirebase;
import smartplug.smartplug.R;


public class DadosActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private FirebaseAuth usuarioFirebase;
    private FloatingActionButton ampliar;
    private LinearLayout ll;
    private static final Random RANDOM = new Random();
    private LineGraphSeries<DataPoint> series;
    private int lastX = 0;
    private RadioButton btnCorrente, btnTensao, btnGasto, btnPotencia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dados);

        usuarioFirebase = ConfiguracaoFirebase.getFirebaseAutenticacao();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        @SuppressLint("WrongViewCast") GraphView graph = (GraphView) findViewById(R.id.grafico_dados);
        //data
        series = new LineGraphSeries<DataPoint>();
        graph.addSeries(series);
        //customize
        Viewport viewport = graph.getViewport();
        viewport.setYAxisBoundsManual(true);
        viewport.setMinY(0);
        viewport.setMaxY(10);
        viewport.setScrollable(true);

       /*
        int i, tam = 200;
        double v = 0;

        // SENO
        GraphViewData[] data = new GraphViewData[tam];
        for(i = 0; i < tam; i++){
            v +=0.3;
            data[i] = new GraphViewData(i, Math.sin(v));
        }

        // Label de Seno
        GraphViewSeries seriesSeno = new GraphViewSeries("Seno", new GraphViewSeries.GraphViewSeriesStyle(Color.BLUE,3), data);


        // COSSENO
        data = new GraphViewData[tam];
        for(i = 0; i < tam; i++){
            v +=0.3;
            data[i] = new GraphViewData(i, Math.cos(v));
        }

        // Label do Cosseno
        GraphViewSeries seriesCosseno = new GraphViewSeries("Cosseno", new GraphViewSeries.GraphViewSeriesStyle(Color.GREEN,3), data);


        LineGraphView graph = new LineGraphView(this, "Dados");
        graph.addSeries(seriesSeno);    // Adiciona a serie do Seno
        graph.addSeries(seriesCosseno); // Adiciona a serie do Cosseno

        graph.setShowLegend(true);
        graph.setLegendAlign(GraphView.LegendAlign.BOTTOM);

        graph.getGraphViewStyle().setGridColor(Color.GRAY);
        graph.getGraphViewStyle().setHorizontalLabelsColor(Color.BLACK);
        graph.getGraphViewStyle().setVerticalLabelsColor(Color.BLACK);
        graph.getGraphViewStyle().setTextSize(15);

        /*graph.setVerticalLabels(new String[]{"y1", "y2", "y3", "y4"});
        graph.setHorizontalLabels(new String[]{"x1", "x2", "x3", "x4"});*/

      /*  graph.setCustomLabelFormatter(new CustomLabelFormatter() {
            @Override
            public String formatLabel(double v, boolean isValueX) {

                if(isValueX){
                    if(v > 2){
                        return ("x1");
                    }
                    else {
                        return ("x2");
                    }
                }
                else{
                    if(v > 2){
                        return ("y1");
                    }
                    else {
                        return ("y2");
                    }
                }

            }
        });

        graph.setViewPort(10, 30); // Limite de visualização
        graph.setScrollable(true); // Ativa o rolamento da tela
        graph.setScalable(true); // Ativa o dimensionamento

      /*  graph.setDrawBackground(true); // Pinta o fundo do grafico
        graph.setBackgroundColor(Color.BLUE);

        ll = (LinearLayout) findViewById(R.id.grafico_dados);
        ll.addView(graph);
        */

        ampliar = (FloatingActionButton) findViewById(R.id.ampliar_grafico);
        ampliar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abreGrafico();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        //we´re going to simulate real time with thread that append data to the graph
        new Thread(new Runnable() {
            @Override
            public void run() {
                // we add 100 new entries
                for(int i = 0; i < 100; i++){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            addEntry();
                        }
                    });

                    // sleep to slow down the add of entries
                    try {
                        Thread.sleep(600);
                    } catch (InterruptedException e) {
                        // manage error ...

                    }
                }
            }
        }).start();
    }

    // add random data to graph
    private void addEntry(){

        // here we choose to display max 10 points on the viewport and we scroll to end
        series.appendData(new DataPoint(lastX++, RANDOM.nextDouble() * 10d), true, 10);

    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.dados, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

       /* //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        } */

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home_dados) {

            abreHome();

        } else if (id == R.id.nav_sobre_dados) {

        } else if (id == R.id.nav_condiguracao_dados) {

        } else if (id == R.id.nav_compartilhar_dados) {

            abrirCompartilhar();

        } else if (id == R.id.nav_deslogar_dados) {

            deslogaUsuario();

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void deslogaUsuario(){
        usuarioFirebase.signOut();
        Intent intent = new Intent(DadosActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void abreHome(){
        Intent intent = new Intent(DadosActivity.this, HomeActivity.class);
        startActivity(intent);
        finish();
    }

    private void abreGrafico(){
        Intent intent = new Intent(DadosActivity.this, GraficoActivity.class);
        startActivity(intent);
    }

    private void abrirCompartilhar(){

        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        String texto = "Olá sou um texto compartilhado";
        sendIntent.putExtra(Intent.EXTRA_TEXT, texto);
        sendIntent.setType("text/plain");
        startActivity(sendIntent);

    }
}
