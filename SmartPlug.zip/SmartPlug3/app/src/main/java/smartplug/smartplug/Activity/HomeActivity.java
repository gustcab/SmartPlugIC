package smartplug.smartplug.Activity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import smartplug.smartplug.DAO.ConfiguracaoFirebase;
import smartplug.smartplug.R;

public class HomeActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private FirebaseAuth usuarioFirebase;
    private DatabaseReference mDatabase;
    private Button btnVerProduto;
    private FloatingActionButton imgAddAparelho;
    private ImageView imglight, imgdados ;
    private TextView forca, dados, guest;


    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference reference = database.getReference();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        usuarioFirebase = ConfiguracaoFirebase.getFirebaseAutenticacao();

        btnVerProduto = (Button) findViewById(R.id.btnVerProduto);
        imgAddAparelho = (FloatingActionButton) findViewById(R.id.imgAdicionaaparelho);
        imglight = (ImageView) findViewById(R.id.imglight);
        imgdados = (ImageView) findViewById(R.id.imgDados);
        forca = (TextView) findViewById(R.id.forca);
        guest = (TextView) findViewById(R.id.txtguest);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        /* final String user_id = (usuarioFirebase.getCurrentUser()).getUid();
        mDatabase = FirebaseDatabase.getInstance().getReference().child("usuario").child(user_id).child("nome");

        guest.setText(mDatabase.toString()); */


        imgAddAparelho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addProduto();

            }
        });

        imgdados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(HomeActivity.this, DadosActivity.class);
                startActivity(intent);

            }
        });

        imglight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (forca.getText() == "Ligado") {
                    Drawable drawable = getResources().getDrawable(R.drawable.ic_light_off);
                    imglight.setImageDrawable(drawable);

                    forca.setText("Desligado");
                } else{

                    Drawable drawable = getResources().getDrawable(R.drawable.light);
                    imglight.setImageDrawable(drawable);

                    forca.setText("Ligado");
            }


            }
        });

        btnVerProduto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verProduto();
            }
        });
    }

    private void addProduto(){

        Intent intent = new Intent(HomeActivity.this, CadastroProdutos.class);
        startActivity(intent);
        finish();
    }

    private void verProduto(){

        Intent intent = new Intent(HomeActivity.this, ProdutosActivity.class);
        startActivity(intent);
        finish();
    }

    private void deslogaUsuario(){
        usuarioFirebase.signOut();
        Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void abreHome(){
        Intent intent = new Intent(HomeActivity.this, HomeActivity.class);
        startActivity(intent);
        finish();
    }

    private void abrirCompartilhar(){

        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        String texto = "Olá sou um texto compartilhado";
        sendIntent.putExtra(Intent.EXTRA_TEXT, texto);
        sendIntent.setType("text/plain");
        startActivity(sendIntent);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);


        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
       /* if (id == R.id.action_settings) {
            return true;
        } */

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {

            abreHome();

        } else if (id == R.id.nav_sobre2) {

        } else if (id == R.id.nav_condiguracao2) {

        } else if (id == R.id.nav_compartilhar2) {

           abrirCompartilhar();

        } else if (id == R.id.nav_deslogar2) {

            deslogaUsuario();

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


}
